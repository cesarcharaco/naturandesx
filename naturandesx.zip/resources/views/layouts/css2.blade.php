<style type="text/css">
	/*.content-wrapper{
	    background-image: url("{{ asset('img/blue-white.jpg') }}") !important;
	    background-position: center;
        background-repeat: no-repeat;
        background-size: 100%;
	  }*/
	.card-black{
	    /*background-color: black !important;*/
	    border-radius: 0px !important;
	    padding: 20px;
	    background: rgba(0, 0, 0, 0.6) !important;
	    color: black;
	    font: 18px Arial, sans-serif;
	  }
	  .input,p, a,.nav-icon{
	    color:#ffa600 !important;
	    border-radius: 10px !important;
	    /*text-align: center;*/
	  }

	  .main-sidebar, .sidebar{
	  	background-color: #0d3357 !important;
	  	border-color: orange !important;
	  }
	  .user-panel,.brand-link{
	  	border-bottom: 1px solid #ffa600 !important;
	  }
	  .border-orange{
	  	border-color: orange !important;
	  }
	  .h1{
	  	color: white !important;
	  }
	  .main-footer{
	  	border-color: white !important;
	  }
</style>