<!doctype html>
<html class="no-js" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php echo $__env->make('layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.css2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo toastr_css(); ?>
    <style type="text/css">
	  body{
	    background-image: url("<?php echo e(asset('img/banner-covid-19.jpg')); ?>") !important;
	    background-position: center center !important;
	    background-repeat: no-repeat !important;
	    background-size: 100% !important;
	    background-attachment: fixed !important;
	    background-color: 
	  }
	  h2{
	    color: white !important;
	  }
	  
	  label{
	  	color: #ffa600;
	  	text-align: center !important;
	  }

	  @media  only screen and (max-width: 2000px)  {
	  	#login2{
	  		width: 90%;
	  	}
	  }
	</style>
</head>
<body class="hold-transition login-page">
    <!-- preloader area end -->
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<?php echo jquery(); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
</html>
<?php /**PATH C:\wamp64\www\naturandesx\resources\views/layouts/app_login.blade.php ENDPATH**/ ?>