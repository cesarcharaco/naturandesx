<div class="collapse multi-collapse" id="collapseExample3" style="position: absolute; margin-left: -8px; width: 100% !important; background-color: white !important;">
    <div class="card-header">
      <a href="#" data-toggle="collapse" data-target="#collapseExample3" aria-expanded="false" aria-controls="collapseExample3" class="btn btn-warning btn-sm boton-tabla text-white" style="border-radius: 5px; float: right;" onclick="cerrar(3)">
        <strong>Cerrar</strong>
      </a>
    </div>
    <div class="card card-body" style="border-top: 3px solid #ffc107;">
      <h4 class="header-title mb-2">Editar datos de cliente <br> <small>Todos los campos (<b style="color: red;">*</b>) son requerido.</small></h4>
        <center>
          <form action="<?php echo e(route('clientes.editar')); ?>" name="registro_clientes" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="nombres_edit">Nombres</label>
                  <input type="text" class="form-control" placeholder="Ingrese nombres" id="nombres_edit" required="required" name="nombres">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for="apellidos_edit">Apellidos</label>
                  <input type="text" class="form-control" placeholder="Ingrese apellidos" id="apellidos_edit" required="required" name="apellidos">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">                          
                  <label for="rut_edit">RUT <b style="color: red;">*</b></label>
                  <div class="row">
                    <div class="col-md-8">
                      <div class="form-group">
                        <input type="text" name="rut" placeholder="Rut del residente" minlength="7" maxlength="8" id="rut_edit" class="form-control" required>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group">
                        <input type="number" name="verificador" min="1" id="verificador_edit" minlength="1" maxlength="1" max="9" value="0" class="form-control" required>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="usuario">Usuario <b style="color: red;">*</b></label>
                  <input type="text" class="form-control" placeholder="Ingrese usuario" name="usuario" required id="usuario_edit" >
                  <?php if($errors->has('usuario')): ?>
                      <small class="form-text text-danger">
                          <?php echo e($errors->first('usuario')); ?>

                       </small>
                  <?php endif; ?>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label for="email_edit">Email</label>
                  <input type="email" class="form-control" placeholder="Ingrese email" name="email" id="email_edit">
                </div>
              </div>
              <?php if(Auth::user()->tipo_usuario == 'Admin'): ?>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="status">Status</label>
                    <select class="form-control" id="status_editar" name="status">
                    </select>
                  </div>
                </div>
              <?php endif; ?>
            </div>
            
              <input type="hidden" id="id_edit" name="id">
              <input type="hidden" id="id_usuario_edit" name="id_usuario">
              <button type="submit" style="float: right;" class="btn btn-warning text-white">Actualizar</button>
          </form>
        </center>
    </div>
</div><?php /**PATH C:\wamp64\www\naturandesx\resources\views/clientes/layouts/edit.blade.php ENDPATH**/ ?>