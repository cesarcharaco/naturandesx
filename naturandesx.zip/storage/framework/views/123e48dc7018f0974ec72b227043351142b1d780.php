<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4 border-orange">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('home')); ?>" class="brand-link">
      <img src="<?php echo e(asset('img/naturandes.jpg')); ?>" alt="Naturandes"
           class="brand-image elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Naturandes</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('dist/img/default-150x150.png')); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="<?php echo e(route('perfil', \Auth::User()->id)); ?>" class="d-block" style="text-transform: uppercase;"><?php echo e(\Auth::User()->usuario); ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-header"><h3 align="center">Menú</h3></li>
          <li class="nav-item">
            <a href="<?php echo e(route('home')); ?>" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt text-info"></i>
              <p class="text">Home</p>
            </a>
          </li>
          <?php if(Auth::user()->tipo_usuario == 'Empleado' ): ?>
          <li class="nav-item">
            <a href="<?php echo e(route('ventas.index')); ?>" class="nav-link">
              <i class="nav-icon far fa-circle text-warning"></i>
              <p>Ventas</p>
            </a>
          </li>
          <?php endif; ?>
          <?php if(Auth::user()->tipo_usuario == 'Admin' ): ?>
          <li class="nav-item">
            <a href="<?php echo e(route('empleados.index')); ?>" class="nav-link">
              <i class="nav-icon far fa-circle text-info"></i>
              <p>Repartidores</p>
            </a>
          </li>
          <?php endif; ?>
          <?php if(Auth::user()->tipo_usuario != 'Cliente' ): ?>
          <li class="nav-item">
            <a href="<?php echo e(route('clientes.index')); ?>" class="nav-link">
              <i class="nav-icon far fa-circle text-info"></i>
              <p>Clientes</p>
            </a>
          </li>
          <?php endif; ?>
          <?php if(Auth::user()->tipo_usuario == 'Admin' ): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('reportes')); ?>" class="nav-link">
                <i class="nav-icon far fa-circle text-info"></i>
                <p>Reportes</p>
              </a>
            </li>
          <?php endif; ?>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH C:\wamp64\www\naturandesx\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>