<?php $__env->startSection('content'); ?>
    <div class="login-box card-black">
      <div class="card-body">
      <h2 align="center" class="mb-4">INICIAR SESIÓN</h2>
      <form action="<?php echo e(route('login')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="mt-4">
          
          <input id="login" type="text" class="border border-warning form-control mb-4 input <?php if($errors->has('usuario') || $errors->has('email')): ?> is-invalid <?php endif; ?>" name="login" value="<?php echo e(old('usuario') ?: old('email')); ?>" required placeholder="Email o Usuario" autocomplete="login" autofocus="">
          <?php if($errors->has('usuario') || $errors->has('email')): ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('usuario') ?: $errors->first('email')); ?></strong>
            </span>
          <?php endif; ?>
          <input id="password" type="password" class="border border-warning form-control mb-4 input <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required placeholder="Contraseña">
          <div class="row">
            <div class="col-6">
              <div class="icheck-primary">
                <input type="checkbox" id="remember">
                <label for="remember">
                  <span style="color: orange;">Recuérdame</span>
                </label>
              </div>
            </div>
            <!-- /.col -->
            <div class="col-6">
              <button type="submit" class="btn btn-block text-white" style="background-color: #ffa600;border-radius: 10px;"><strong>Iniciar sesión</strong></button>
            </div>
            <!-- /.col -->
          </div>
        </div>
      </form>

      <?php if(Route::has('password.request')): ?>
        <p class="mt-3">
          <a href="#" style="float: left !important;">¿Olvidó su contraseña?</a>
        </p>
      <?php endif; ?>
      <p class="mt-2">
        <a href="<?php echo e(route('registerc')); ?>" class="text-center" style="float: left !important;">Registro de nuevo clientes</a>
      </p>
        
      </div>
    </div>
    <!-- <div class="col-md-6"></div> -->
<!-- /.login-box -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\naturandesx\resources\views/auth/login.blade.php ENDPATH**/ ?>