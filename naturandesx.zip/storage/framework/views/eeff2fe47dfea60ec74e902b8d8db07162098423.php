<?php $__env->startSection('css'); ?>
  <title>Repartidores</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Repartidores</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Repartidores</a></li>
          <li class="breadcrumb-item active" style="color:black;">Registros</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="card card-primary card-outline">
      <div class="card-body">
        <div class="row mb-3">
          <div class="col-md-12">
            <a class="btn btn-primary btn-sm text-uppercase float-right text-white" id="btnRegistrar" data-toggle="collapse" href="#RegistrarEmpleado" role="button" aria-expanded="false" aria-controls="RegistrarEmpleado" onclick="RegistrarEmpleado()">
              <strong>Registrar</strong>
            </a>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <?php echo $__env->make('empleados.layouts.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('empleados.layouts.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('empleados.layouts.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('empleados.layouts.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
        <div class="row" style="position: relative !important;">
          <div class="col-md-12" style="position: relative !important;">
            <div id="example1_wrapper" class="dataTables_wrapper dt-bootstrap4" style="width: 100% !important;">
              <table id="example1" class="table table-bordered table-hover table-striped dataTable dtr-inline collapsed border border-orange" style="width: 100% !important;">
                  <thead class="text-capitalize bg-primary">
                    <tr class="border-orange">
                      <th>Nombres</th>
                      <th>Rut</th>
                      <th>Teléfono</th>
                      <th>Email</th>
                      <th>Usuario</th>
                      <th>Status</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Auth::user()->tipo_usuario == 'Admin'): ?>
                          <?php if($key->usuario->tipo_usuario!="Admin"): ?>
                          <tr>
                              <td><?php echo $key->nombres; ?> <?php echo $key->apellidos; ?></td>
                              <td><?php echo $key->rut; ?></td>
                              <td><?php echo $key->telefono; ?></td>
                              <td>
                                <?php if($key->usuario->email == null): ?>
                                  No posee
                                <?php else: ?>  
                                  <?php echo $key->usuario->email; ?>

                                <?php endif; ?>
                              </td>
                              <td><?php echo $key->usuario->usuario; ?></td>
                              <?php if( $key->status == 'Activo'): ?>
                                <td class="text-success"><strong><?php echo $key->status; ?></strong></td>
                              <?php else: ?>
                                <td class="text-danger"><strong><?php echo $key->status; ?></strong></td>
                              <?php endif; ?>
                              <td>                                
                                <a data-toggle="collapse" data-target="#collapseExample2" aria-expanded="false" aria-controls="collapseExample2" class="btn btn-success btn-sm boton-tabla shadow botonesEditEli" style="border-radius: 5px;" onclick="verEmpleado('<?php echo e($key->id); ?>','<?php echo e($key->qr->codigo); ?>','<?php echo e($key->nombres); ?>','<?php echo e($key->apellidos); ?>','<?php echo e($key->usuario->usuario); ?>','<?php echo e($key->usuario->email); ?>','<?php echo e($key->rut); ?>')">
                                    <i class="fa fa-fw fa-eye text-white"></i>
                                </a>
                                <a data-toggle="collapse" data-target="#collapseExample3" aria-expanded="false" aria-controls="collapseExample3" class="btn btn-warning btn-sm boton-tabla shadow botonesEditEli" style="border-radius: 5px;" onclick="editarEmpleado('<?php echo e($key->id); ?>','<?php echo e($key->usuario->id); ?>','<?php echo e($key->nombres); ?>','<?php echo e($key->apellidos); ?>','<?php echo e($key->usuario->usuario); ?>','<?php echo e($key->usuario->email); ?>','<?php echo e($key->rut); ?>','<?php echo e($key->telefono); ?>','<?php echo e($key->status); ?>','<?php echo e($key->direccion); ?>')">
                                    <i class="fa fa-fw fa-edit text-white"></i>
                                  </a>
                                  <a data-toggle="collapse" data-target="#collapseExample4" aria-expanded="false" aria-controls="collapseExample4" class="btn btn-danger btn-sm boton-tabla shadow botonesEditEli" style="border-radius: 5px;" onclick="eliminarEmpleado('<?php echo e($key->id); ?>','<?php echo e($key->usuario->id); ?>','<?php echo e($key->qr->id); ?>')">
                                      <i class="fa fa-fw fa-trash text-white"></i>
                              </td>
                          </tr>
                          <?php endif; ?>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

  <script type="text/javascript">
    function RegistrarEmpleado() {
      $('#btnRegistrar').fadeOut('fast');
      $('#example1_wrapper').fadeOut('fast');
    }

    function verEmpleado(id,codigo_qr,nombres,apellidos,email,rut) {
      $('#example1_wrapper').fadeOut('fast');
      $('#btnRegistrar').fadeOut('fast');
      $('#id').val(id);
      $('#codigo_qr').val(codigo_qr);
      $('#nombres_carnet').text(nombres);
      $('#apellidos_carnet').text(apellidos);
      $('#email_carnet').text(email);
      $('#rut_carnet').text(rut);
      $("#img_qr").empty();
      $("#img_qr").append('<img src="<?php echo asset("'+ codigo_qr +'"); ?>" style="width: 200px; height: 200px; border-radius: 30px !important;">');
    }

    function editarEmpleado(id,id_usuario,nombres,apellidos,usuario,email,rut,telefono,status,direccion) {
      var opcion = $('#nameRegistrar').val();
      $('#example1_wrapper').fadeOut('fast');
      $('#btnRegistrar').fadeOut('fast');
      $('#id_edit').val(id);
      $('#id_usuario').val(id_usuario);
      $('#nombres_edit').val(nombres);
      $('#apellidos_edit').val(apellidos);
      $('#usuario_edit').val(usuario);
      $('#email_edit').val(email);
      $('#rut_edit').val(rut.substr(0,(rut.length-2)));
      $('#verificador_edit').val(rut.substr(-1,(rut.length)));
      $('#telefono_edit').val(telefono);
      if(status=="Activo") {
        $("#status_editar").empty();
        $("#status_editar").append('<option selected value="Activo">Activo</option>');
        $("#status_editar").append('<option value="Inactivo">Inactivo</option>');
      } else {
        $("#status_editar").empty();
        $("#status_editar").append('<option value="Activo">Activo</option>');
        $("#status_editar").append('<option selected value="Inactivo">Inactivo</option>');
      }
      $('#direccion_edit').val(direccion);



    }

    function eliminarEmpleado(id,id_usuario,id_qr){
      $('#example1_wrapper').fadeOut('fast');
      $('#btnRegistrar').fadeOut('fast');
      $('#id_EmpleadoE').val(id);
      $('#id_delete').val(id);
      $('#id_qr_delete').val(id_qr);
      $('#id_usuarioDelete').val(id_usuario);
    }

    function cerrar(opcion) {
      $('#example1_wrapper').fadeIn('fast');
      $('#nameRegistrar').val(1);
      $('#btnRegistrar').show();
    }
  </script>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\naturandesx\resources\views/empleados/index.blade.php ENDPATH**/ ?>