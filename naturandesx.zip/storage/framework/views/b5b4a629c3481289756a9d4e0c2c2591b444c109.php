<?php $__env->startSection('css'); ?>
  <title>Dashboard</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Home</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active" style="color: black;">Tablero</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <!-- Top Statistics -->
  <?php if(Auth::user()->tipo_usuario == 'Admin' ): ?>
    <div class="row">
      <div class="col-md-6">
        <div class="card card-outline card-primary">
          <div class="card-header">
            <h3 class="card-title">Ventas de los últimos 7 días</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
              </button>
            </div>
            <!-- /.card-tools -->
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div style="width:100%;">
                <?php echo $chartjs->render(); ?>

            </div>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <div class="col-md-6">
        <div class="card card-outline card-primary">
          <div class="card-header">
            <h3 class="card-title">Status de ventas de los últimos 7 meses</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
              </button>
            </div>
            <!-- /.card-tools -->
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div style="width:100%;">
                <?php echo $chartjs1->render(); ?>

            </div>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
    <div class="row">
      <div class="col-xl-8 col-sm-6">
        <div class="card card-outline card-primary">
          <div class="card-body">
            <table class="table table-curved">
              <thead>
                <tr align="center">
                  <th colspan="2">Repartidor</th>
                  <th>Promociones vendida</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $empleados_ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr align="center">
                  <th colspan="2"><?php echo e($key->empleado->nombres); ?></th>
                  <th><?php echo e($key->venta->cantidad); ?></th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="col-xl-4 col-sm-6">
        <div class="card card-outline card-primary">
          <div class="card-body">
            <table class="table table-curved">
              <thead>
                <tr align="center">
                  <th>Promociones activas</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $promociones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr align="center">
                  <th><?php echo e($key->promocion); ?> - <?php echo e($key->monto); ?> $</th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-xl-12 col-sm-12">
        <div class="card card-outline card-primary">
          <div class="card-body">
            <h3>Ventas del día <?php echo date('d/m/Y'); ?></h3>
            <table class="table table-curved" >
              <thead>
                <tr align="center">
                  <th colspan="2">Cliente</th>
                  <th>Cantidad de Promoción</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr align="center">
                  <th colspan="2"><?php echo e($key->cliente->nombres); ?> <?php echo e($key->cliente->apellidos); ?></th>
                  <th><?php echo e($key->cantidad); ?></th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  <?php elseif(Auth::user()->tipo_usuario == 'Repartidor'): ?>
    <div class="row">
      <div class="col-xl-12 col-sm-12">
        <div class="card card-outline card-primary">
          <div class="card-body">
            <h3>Ventas del día <?php echo date('d/m/Y'); ?></h3>
            <table class="table table-curved" >
              <thead>
                <tr align="center">
                  <th colspan="2">Cliente</th>
                  <th>Cantidad de Promoción</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr align="center">
                  <th colspan="2"><?php echo e($key->cliente->nombres); ?> <?php echo e($key->cliente->apellidos); ?></th>
                  <th><?php echo e($key->cantidad); ?></th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  <?php elseif(Auth::user()->tipo_usuario == 'Empleado'): ?>
    <div class="row">
      <div class="col-xl-12 col-sm-12">
        <div class="card card-outline card-primary">
          <div class="card-body">
            <h3>Compras del día <?php echo date('d/m/Y'); ?></h3>
            <table class="table table-curved" >
              <thead>
                <tr align="center">
                  <th colspan="2">Cliente</th>
                  <th>Cantidad de Promoción</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $key->empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key2->pivot->id_empleado==$empleado->id): ?>
                <tr align="center">
                  <th colspan="2"><?php echo e($key->cliente->nombres); ?> <?php echo e($key->cliente->apellidos); ?></th>
                  <th><?php echo e($key->cantidad); ?></th>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <?php else: ?>
    <div class="row">
      <div class="col-xl-12 col-sm-12">
        <div class="card card-outline card-primary">
          <div class="card-body">
            <h3>Compras del día <?php echo date('d/m/Y'); ?></h3>
            <table class="table table-curved" >
              <thead>
                <tr align="center">
                  <th colspan="2">Repartidor</th>
                  <th>Cantidad de Promoción</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $key->empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key->id_cliente  ==$cliente->id): ?>
                <tr align="center">
                  <th colspan="2"><?php echo e($key2->nombres); ?> <?php echo e($key2->apellidos); ?></th>
                  <th><?php echo e($key->cantidad); ?></th>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/line-chart.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\naturandesx\resources\views/home.blade.php ENDPATH**/ ?>