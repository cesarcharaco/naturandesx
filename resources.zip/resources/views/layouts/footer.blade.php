 <footer class="main-footer border">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.5
    </div>
    <strong>© 2020 Copyright Naturandes. Todos los derechos reservados</strong>
 </footer>