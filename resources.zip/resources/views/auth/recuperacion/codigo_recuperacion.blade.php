<!DOCTYPE html>
<html>
<head>
	<title>Código de Recuperación</title>
</head>
<body>
	<h3>Su Código de recuperación es:</h3> <b> {{ $codigo }}</b>
</body>
</html>